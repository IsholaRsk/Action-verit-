"use client";

import { useState } from "react";
import { useCart } from "@/lib/cart-store";
import type { Product } from "@/lib/products";
import clsx from "clsx";

export default function ProductActions({ product }: { product: Product }) {
  const [size, setSize] = useState(product.sizes[0]);
  const addItem = useCart((s) => s.addItem);

  return (
    <div className="mt-6">
      <p className="text-sm text-muted mb-2">Taille</p>
      <div className="flex gap-2 flex-wrap">
        {product.sizes.map((s) => (
          <button
            key={s}
            onClick={() => setSize(s)}
            className={clsx(
              "px-4 py-2 rounded border text-sm transition",
              size === s
                ? "border-accent text-accent"
                : "border-border text-muted hover:border-white hover:text-white"
            )}
          >
            {s}
          </button>
        ))}
      </div>

      <button
        onClick={() =>
          addItem({
            id: product.id,
            slug: product.slug,
            name: product.name,
            price: product.price,
            image: product.image,
            size,
          })
        }
        disabled={product.stock === 0}
        className="mt-6 w-full bg-accent text-black py-3 rounded font-medium tracking-wide hover:opacity-90 transition disabled:opacity-40"
      >
        {product.stock === 0 ? "RUPTURE DE STOCK" : "AJOUTER AU PANIER"}
      </button>
    </div>
  );
}
