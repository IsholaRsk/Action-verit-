"use client";

import { useCart } from "@/lib/cart-store";
import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";

export default function CartDrawer() {
  const { items, isOpen, toggle, removeItem, updateQty, totalPrice } = useCart();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-50"
          onClick={() => toggle(false)}
        />
      )}
      <aside
        className={`fixed top-0 right-0 h-full w-full sm:w-[420px] bg-panel border-l border-border z-50 transform transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between px-6 h-16 border-b border-border">
          <h2 className="font-semibold tracking-wide">VOTRE PANIER</h2>
          <button onClick={() => toggle(false)} className="text-muted hover:text-white">
            ✕
          </button>
        </div>

        <div className="p-6 flex flex-col gap-5 overflow-y-auto h-[calc(100%-180px)]">
          {items.length === 0 && (
            <p className="text-muted text-sm">Votre panier est vide.</p>
          )}
          {items.map((item) => (
            <div key={item.id + item.size} className="flex gap-4">
              <div className="relative w-20 h-24 flex-shrink-0 rounded overflow-hidden bg-panel2">
                <Image src={item.image} alt={item.name} fill className="object-cover" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">{item.name}</p>
                <p className="text-xs text-muted">Taille : {item.size}</p>
                <div className="flex items-center gap-2 mt-2">
                  <button
                    className="w-6 h-6 border border-border rounded text-xs"
                    onClick={() => updateQty(item.id, item.size, item.qty - 1)}
                  >
                    -
                  </button>
                  <span className="text-sm">{item.qty}</span>
                  <button
                    className="w-6 h-6 border border-border rounded text-xs"
                    onClick={() => updateQty(item.id, item.size, item.qty + 1)}
                  >
                    +
                  </button>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm">${item.price * item.qty}</p>
                <button
                  onClick={() => removeItem(item.id, item.size)}
                  className="text-xs text-muted hover:text-accent mt-2"
                >
                  Retirer
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="absolute bottom-0 w-full border-t border-border p-6 bg-panel">
          <div className="flex justify-between mb-4 text-sm">
            <span className="text-muted">Sous-total</span>
            <span className="font-semibold">${totalPrice().toFixed(2)}</span>
          </div>
          <Link
            href="/checkout"
            onClick={() => toggle(false)}
            className={`block text-center w-full py-3 rounded font-medium tracking-wide transition ${
              items.length === 0
                ? "bg-panel2 text-muted pointer-events-none"
                : "bg-accent text-black hover:opacity-90"
            }`}
          >
            PASSER LA COMMANDE
          </Link>
        </div>
      </aside>
    </>
  );
}
