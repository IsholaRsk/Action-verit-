import Link from "next/link";
import Image from "next/image";
import type { Product } from "@/lib/products";

export default function ProductCard({ product }: { product: Product }) {
  return (
    <Link href={`/product/${product.slug}`} className="group block">
      <div className="relative aspect-[3/4] rounded-lg overflow-hidden bg-panel2">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover group-hover:scale-105 transition duration-500"
        />
        {product.tags.includes("sale") && (
          <span className="absolute top-3 left-3 bg-accent text-black text-[10px] font-bold px-2 py-1 rounded">
            SALE
          </span>
        )}
      </div>
      <div className="mt-3">
        <p className="text-sm font-medium">{product.name}</p>
        <div className="flex gap-2 mt-1 text-sm">
          <span>${product.price}</span>
          {product.compareAtPrice && (
            <span className="line-through-price">${product.compareAtPrice}</span>
          )}
        </div>
      </div>
    </Link>
  );
}
