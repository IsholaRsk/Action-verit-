"use client";

import Link from "next/link";
import { useCart } from "@/lib/cart-store";
import { useEffect, useState } from "react";

export default function Header() {
  const toggle = useCart((s) => s.toggle);
  const totalItems = useCart((s) => s.totalItems);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link href="/" className="font-bold tracking-widest text-lg">
          LUNA<span className="text-accent">CORE</span>
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm text-muted">
          <Link href="/category/new" className="hover:text-white transition">
            NEW
          </Link>
          <Link href="/category/men" className="hover:text-white transition">
            MEN
          </Link>
          <Link href="/category/women" className="hover:text-white transition">
            WOMEN
          </Link>
          <Link href="/category/accessories" className="hover:text-white transition">
            ACCESSORIES
          </Link>
        </nav>
        <div className="flex items-center gap-5 text-sm">
          <Link href="/account" className="hidden sm:inline hover:text-white text-muted">
            LOG IN
          </Link>
          <button
            onClick={() => toggle(true)}
            className="relative hover:text-accent transition"
          >
            CART
            {mounted && totalItems() > 0 && (
              <span className="ml-1 text-accent">({totalItems()})</span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
