export default function Footer() {
  return (
    <footer className="border-t border-border mt-20">
      <div className="max-w-7xl mx-auto px-6 py-10 flex flex-col sm:flex-row justify-between gap-6 text-xs text-muted">
        <div className="flex gap-6">
          <span>SHIPPING</span>
          <span>ABOUT US</span>
          <span>HELP</span>
        </div>
        <div className="flex gap-6">
          <span>CONTACT US</span>
          <span>PAYMENT</span>
          <span>BLOG</span>
        </div>
        <div className="flex gap-6">
          <span>INSTAGRAM</span>
          <span>YOUTUBE</span>
          <span>TIKTOK</span>
          <span>TELEGRAM</span>
        </div>
      </div>
      <div className="text-center text-[10px] text-muted pb-6">
        © {new Date().getFullYear()} LUNACORE — Made in Bénin, since 2026.
      </div>
    </footer>
  );
}
