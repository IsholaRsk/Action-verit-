import { NextRequest, NextResponse } from "next/server";

// In-memory store as placeholder — swap for Prisma/Postgres in production.
// See lib/db.ts for the scale-ready schema this API is designed against.
const orders: any[] = [];

export async function POST(req: NextRequest) {
  const body = await req.json();

  if (!body.email || !body.items || body.items.length === 0) {
    return NextResponse.json(
      { error: "Email et articles requis." },
      { status: 400 }
    );
  }

  const order = {
    id: `ORD-${Date.now()}`,
    email: body.email,
    shipping: body.shipping,
    items: body.items,
    total: body.total,
    status: "pending_payment",
    createdAt: new Date().toISOString(),
  };
  orders.push(order);

  // TODO production: create a Stripe Checkout Session here and return its URL:
  // const session = await stripe.checkout.sessions.create({ ... });
  // return NextResponse.json({ orderId: order.id, checkoutUrl: session.url });

  return NextResponse.json({ orderId: order.id, status: "created" });
}

export async function GET() {
  return NextResponse.json({ orders });
}
