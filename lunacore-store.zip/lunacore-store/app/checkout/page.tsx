"use client";

import { useCart } from "@/lib/cart-store";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function CheckoutPage() {
  const { items, totalPrice, clear } = useCart();
  const router = useRouter();
  const [form, setForm] = useState({
    email: "",
    fullName: "",
    address: "",
    city: "",
    country: "Bénin",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email,
          shipping: form,
          items,
          total: totalPrice(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur lors de la commande.");
      clear();
      router.push(`/checkout/success?order=${data.orderId}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-6 py-20 text-center">
        <p className="text-muted">Votre panier est vide.</p>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-12 grid md:grid-cols-2 gap-12">
      <form onSubmit={handleSubmit} className="space-y-4">
        <h1 className="text-xl font-semibold mb-4">Informations de livraison</h1>
        <input
          required
          type="email"
          placeholder="Email"
          className="w-full bg-panel2 border border-border rounded px-4 py-3 text-sm outline-none focus:border-accent"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <input
          required
          placeholder="Nom complet"
          className="w-full bg-panel2 border border-border rounded px-4 py-3 text-sm outline-none focus:border-accent"
          value={form.fullName}
          onChange={(e) => setForm({ ...form, fullName: e.target.value })}
        />
        <input
          required
          placeholder="Adresse"
          className="w-full bg-panel2 border border-border rounded px-4 py-3 text-sm outline-none focus:border-accent"
          value={form.address}
          onChange={(e) => setForm({ ...form, address: e.target.value })}
        />
        <input
          required
          placeholder="Ville"
          className="w-full bg-panel2 border border-border rounded px-4 py-3 text-sm outline-none focus:border-accent"
          value={form.city}
          onChange={(e) => setForm({ ...form, city: e.target.value })}
        />
        <input
          required
          placeholder="Pays"
          className="w-full bg-panel2 border border-border rounded px-4 py-3 text-sm outline-none focus:border-accent"
          value={form.country}
          onChange={(e) => setForm({ ...form, country: e.target.value })}
        />
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-accent text-black py-3 rounded font-medium tracking-wide hover:opacity-90 transition disabled:opacity-50"
        >
          {loading ? "TRAITEMENT..." : "CONFIRMER LA COMMANDE"}
        </button>
        <p className="text-xs text-muted">
          Paiement de démonstration — branchez Stripe dans /app/api/orders/route.ts pour un paiement réel.
        </p>
      </form>

      <div>
        <h2 className="text-lg font-semibold mb-4">Récapitulatif</h2>
        <div className="space-y-3">
          {items.map((item) => (
            <div key={item.id + item.size} className="flex justify-between text-sm">
              <span>
                {item.name} ({item.size}) × {item.qty}
              </span>
              <span>${item.price * item.qty}</span>
            </div>
          ))}
        </div>
        <div className="border-t border-border mt-4 pt-4 flex justify-between font-semibold">
          <span>Total</span>
          <span>${totalPrice().toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}
