import Link from "next/link";

export default function SuccessPage({
  searchParams,
}: {
  searchParams: { order?: string };
}) {
  return (
    <div className="max-w-xl mx-auto px-6 py-24 text-center">
      <h1 className="text-2xl font-semibold mb-4">Merci pour votre commande 🎉</h1>
      <p className="text-muted mb-2">Numéro de commande :</p>
      <p className="font-mono text-accent mb-8">{searchParams.order}</p>
      <Link
        href="/"
        className="inline-block bg-accent text-black px-6 py-3 rounded font-medium hover:opacity-90 transition"
      >
        RETOUR À LA BOUTIQUE
      </Link>
    </div>
  );
}
