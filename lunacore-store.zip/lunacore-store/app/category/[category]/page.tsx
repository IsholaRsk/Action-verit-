import ProductCard from "@/components/ProductCard";
import { getAllProducts, getProductsByCategory } from "@/lib/products";

export function generateStaticParams() {
  return [
    { category: "all" },
    { category: "men" },
    { category: "women" },
    { category: "accessories" },
    { category: "new" },
  ];
}

export default function CategoryPage({
  params,
}: {
  params: { category: string };
}) {
  const products =
    params.category === "new"
      ? getAllProducts().filter((p) => p.tags.includes("new"))
      : getProductsByCategory(params.category);

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <h1 className="text-2xl font-semibold tracking-wide mb-8 uppercase">
        {params.category === "all" ? "Tous les produits" : params.category}
      </h1>
      {products.length === 0 ? (
        <p className="text-muted">Aucun produit dans cette catégorie.</p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
