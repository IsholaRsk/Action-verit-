import Link from "next/link";
import Image from "next/image";
import ProductCard from "@/components/ProductCard";
import { getAllProducts } from "@/lib/products";

export default function HomePage() {
  const products = getAllProducts();
  const newArrivals = products.filter((p) => p.tags.includes("new")).slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section className="relative h-[70vh] min-h-[480px] overflow-hidden">
        <Image
          src="https://images.unsplash.com/photo-1520975954732-35dd22299614?w=1600"
          alt="SS23 Sale"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 max-w-7xl mx-auto h-full flex flex-col justify-end px-6 pb-16">
          <h1 className="text-4xl sm:text-6xl font-bold">
            SS23 <span className="text-accent">SALE</span>
          </h1>
          <p className="text-muted mt-2 max-w-md">
            Style and comfort in one piece — Feel the difference with our
            comfortable and stylish collections.
          </p>
          <Link
            href="/category/all"
            className="mt-6 inline-block bg-accent text-black w-fit px-6 py-3 rounded font-medium hover:opacity-90 transition"
          >
            SHOP NOW
          </Link>
        </div>
      </section>

      {/* New arrivals */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-xl font-semibold tracking-wide">NEW ARRIVALS</h2>
          <Link href="/category/all" className="text-sm text-muted hover:text-white">
            SHOP ALL
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {newArrivals.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Category tiles */}
      <section className="max-w-7xl mx-auto px-6 pb-16 grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: "MEN'S CLOTHING", href: "/category/men", img: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=800" },
          { label: "ACCESSORIES", href: "/category/accessories", img: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800" },
          { label: "WOMEN'S CLOTHING", href: "/category/women", img: "https://images.unsplash.com/photo-1548624313-0396c75f1b6a?w=800" },
        ].map((c) => (
          <Link key={c.href} href={c.href} className="relative h-72 rounded-lg overflow-hidden group">
            <Image src={c.img} alt={c.label} fill className="object-cover group-hover:scale-105 transition duration-500" />
            <div className="absolute inset-0 bg-black/30" />
            <span className="absolute bottom-4 left-4 font-medium tracking-wide">{c.label}</span>
          </Link>
        ))}
      </section>

      {/* Collection banner */}
      <section className="max-w-7xl mx-auto px-6 pb-20">
        <div className="relative h-96 rounded-lg overflow-hidden flex items-center justify-center text-center">
          <Image
            src="https://images.unsplash.com/photo-1490114538077-0a7f8cb49891?w=1600"
            alt="Lunacore PF23 Collection"
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-black/50" />
          <div className="relative z-10">
            <h3 className="text-3xl font-bold">LUNACORE PF23 COLLECTION</h3>
            <p className="text-muted mt-2 max-w-md mx-auto text-sm">
              Explore the boundaries of style with our Pre-Fall 2023 collection.
            </p>
            <Link
              href="/category/all"
              className="mt-6 inline-block border border-white px-6 py-3 rounded hover:bg-white hover:text-black transition"
            >
              VIEW COLLECTION
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
