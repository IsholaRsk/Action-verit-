import { getAllProducts, getProductBySlug } from "@/lib/products";
import { notFound } from "next/navigation";
import Image from "next/image";
import ProductActions from "@/components/ProductActions";

export function generateStaticParams() {
  return getAllProducts().map((p) => ({ slug: p.slug }));
}

export default function ProductPage({ params }: { params: { slug: string } }) {
  const product = getProductBySlug(params.slug);
  if (!product) return notFound();

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 grid md:grid-cols-2 gap-12">
      <div className="relative aspect-[3/4] rounded-lg overflow-hidden bg-panel2">
        <Image src={product.image} alt={product.name} fill className="object-cover" />
      </div>
      <div>
        <h1 className="text-2xl font-semibold">{product.name}</h1>
        <div className="flex gap-3 mt-2 text-lg">
          <span>${product.price}</span>
          {product.compareAtPrice && (
            <span className="line-through-price">${product.compareAtPrice}</span>
          )}
        </div>
        <p className="text-muted mt-6 leading-relaxed">{product.description}</p>
        <ProductActions product={product} />
        <p className="text-xs text-muted mt-6">
          {product.stock > 0 ? `${product.stock} en stock` : "Rupture de stock"}
        </p>
      </div>
    </div>
  );
}
