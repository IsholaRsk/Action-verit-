import Link from "next/link";

export default function NotFound() {
  return (
    <div className="max-w-xl mx-auto px-6 py-24 text-center">
      <h1 className="text-3xl font-semibold mb-4">404</h1>
      <p className="text-muted mb-8">Cette page n'existe pas.</p>
      <Link href="/" className="text-accent underline">
        Retour à l'accueil
      </Link>
    </div>
  );
}
