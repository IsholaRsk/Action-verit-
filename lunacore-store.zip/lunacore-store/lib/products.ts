export type Product = {
  id: string;
  slug: string;
  name: string;
  price: number;
  compareAtPrice?: number;
  category: "men" | "women" | "accessories";
  image: string;
  images: string[];
  description: string;
  sizes: string[];
  stock: number;
  tags: string[];
};

export const PRODUCTS: Product[] = [
  {
    id: "p1",
    slug: "kimono-liu-kang",
    name: "Kimono Liu Kang",
    price: 180,
    compareAtPrice: 260,
    category: "men",
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=800",
    images: [
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=1200",
      "https://images.unsplash.com/photo-1520975954732-35dd22299614?w=1200",
    ],
    description:
      "Kimono technique en coton lourd, coupe oversize, imprimé calligraphié dans le dos. Pièce signature de la collection SS23.",
    sizes: ["S", "M", "L", "XL"],
    stock: 24,
    tags: ["new", "sale"],
  },
  {
    id: "p2",
    slug: "asobai-stalker",
    name: "Asobai Stalker",
    price: 165,
    compareAtPrice: 220,
    category: "men",
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800",
    images: ["https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1200"],
    description: "Veste utilitaire multi-poches, tissu déperlant, capuche ajustable.",
    sizes: ["S", "M", "L", "XL"],
    stock: 15,
    tags: ["new", "sale"],
  },
  {
    id: "p3",
    slug: "shadow-hoodie",
    name: "Shadow Tech Hoodie",
    price: 140,
    category: "men",
    image: "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800",
    images: ["https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=1200"],
    description: "Hoodie technique gris anthracite, doublure polaire, capuche renforcée.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    stock: 32,
    tags: ["new"],
  },
  {
    id: "p4",
    slug: "raven-longsleeve",
    name: "Raven Longsleeve",
    price: 95,
    category: "men",
    image: "https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=800",
    images: ["https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=1200"],
    description: "T-shirt manches longues en jersey lourd, print graphique minimal.",
    sizes: ["S", "M", "L", "XL"],
    stock: 40,
    tags: ["new"],
  },
  {
    id: "p5",
    slug: "duo-print-crewneck",
    name: "Duo Print Crewneck",
    price: 110,
    category: "men",
    image: "https://images.unsplash.com/photo-1517438476312-10d79c077509?w=800",
    images: ["https://images.unsplash.com/photo-1517438476312-10d79c077509?w=1200"],
    description: "Sweat col rond épais, print duo à l'avant, finitions côtelées.",
    sizes: ["S", "M", "L", "XL"],
    stock: 18,
    tags: [],
  },
  {
    id: "p6",
    slug: "tactical-sling-bag",
    name: "Tactical Sling Bag",
    price: 85,
    category: "accessories",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800",
    images: ["https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=1200"],
    description: "Sac banane tactique multi-compartiments, sangle réglable, résistant à l'eau.",
    sizes: ["Unique"],
    stock: 50,
    tags: [],
  },
  {
    id: "p7",
    slug: "horn-headpiece",
    name: "Horn Headpiece",
    price: 60,
    category: "women",
    image: "https://images.unsplash.com/photo-1445205170230-053b83016050?w=800",
    images: ["https://images.unsplash.com/photo-1445205170230-053b83016050?w=1200"],
    description: "Accessoire de tête sculptural, pièce éditoriale de la collection PF23.",
    sizes: ["Unique"],
    stock: 10,
    tags: ["new"],
  },
  {
    id: "p8",
    slug: "cropped-tech-set",
    name: "Cropped Tech Set",
    price: 130,
    category: "women",
    image: "https://images.unsplash.com/photo-1548624313-0396c75f1b6a?w=800",
    images: ["https://images.unsplash.com/photo-1548624313-0396c75f1b6a?w=1200"],
    description: "Ensemble crop top et pantalon technique, taille haute, coupe ajustée.",
    sizes: ["XS", "S", "M", "L"],
    stock: 22,
    tags: ["new"],
  },
];

export function getAllProducts() {
  return PRODUCTS;
}

export function getProductBySlug(slug: string) {
  return PRODUCTS.find((p) => p.slug === slug) ?? null;
}

export function getProductsByCategory(category: string) {
  if (category === "all") return PRODUCTS;
  return PRODUCTS.filter((p) => p.category === category);
}
